--每次服务器启动时执行的脚本
-- database.py 脚本的start参数文件
sudo /etc/init.d/mysqld start

#include "nullCmd.h"
int main()
{
	Cmd::ZipCmdPackNullCmd zip;
	return 0;
}

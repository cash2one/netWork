#include<iostream>
#include<mysql.h>
#include "global.h"
#include "baseSqlPool.h"
#include "testAutoPtr.h"
using namespace std;
using namespace Global;
int main()
{
	return 1;
}


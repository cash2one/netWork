//全局函数声明

#ifndef FUN_H
#define FUN_H
#include"com.h"

bool chkIpInfo(const IpInfo &ipInfo);          //查找ipInfo是否找到(ture找到)

#endif
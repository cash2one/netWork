//配置读取函数声明
#ifndef READ_CONF_H
#define READ_CONF_H

void readHallSer(const char *fileName);

#endif

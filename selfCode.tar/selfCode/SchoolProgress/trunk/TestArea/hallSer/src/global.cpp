//全局变量声明
#include"com.h"
set<IpInfo> ipInfoSet;     //与大厅服务器相连的游戏服务器ip信息集合
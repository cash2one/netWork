#include"readConf.h"
int main(void)
{
    char path[] = "config/hallSer.xml";
    readHallSer(path);
    return 1;
}


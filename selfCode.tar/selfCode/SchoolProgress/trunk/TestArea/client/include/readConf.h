//配置读取函数声明
#ifndef READ_CONF_H
#define READ_CONF_H
#include"client.h"

Client* readClient(const char *fileName);

#endif

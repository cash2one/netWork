#ifndef COM_H
#define COM_H
#include<iostream>
#include<set>
#include<vector>
#include<map>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
using namespace std;

//宏定义处
#define IPADDR 20          //ip地址长度
#define SERNAME 40         //服务器名称长度

typedef unsigned long int ULI;

#endif

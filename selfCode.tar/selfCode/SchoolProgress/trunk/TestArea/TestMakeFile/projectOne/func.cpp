#include "func.h"
void func(const Test &testInst)
{
	testInst.print();
}

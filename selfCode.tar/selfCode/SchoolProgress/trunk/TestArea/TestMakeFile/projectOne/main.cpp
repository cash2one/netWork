#include "func.h"
int main()
{
	Test testInst(1,2);
	func(testInst);
	return 0;
}

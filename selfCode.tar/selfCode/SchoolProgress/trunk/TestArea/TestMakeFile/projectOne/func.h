#ifndef FUNC_H
#define FUNC_H
#include "common/test.h"
#include <iostream>
using namespace std;
void func(const Test &testInst);


#endif

#include "test.h"
int main()
{
	Test testInst;
	testInst.print();
	return 0;
}

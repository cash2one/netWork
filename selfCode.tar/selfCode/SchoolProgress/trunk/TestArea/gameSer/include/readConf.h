//配置读取函数声明
#ifndef READ_CONF_H
#define READ_CONF_H
#include"gameSer.h"

GameSer* readGameSer(const char *fileName);

#endif
